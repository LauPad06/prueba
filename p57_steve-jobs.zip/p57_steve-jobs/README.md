# P57_Steve Jobs

A Pen created on CodePen.io. Original URL: [https://codepen.io/LauPad06/pen/VwQgzEa](https://codepen.io/LauPad06/pen/VwQgzEa).

